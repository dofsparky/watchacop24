# QCAv9

Single-turn local constitutional analyzer for llama.cpp.

## Key behavior

- Uses `llama-cli` in **single-turn** mode.
- Adds `--simple-io`, `--no-display-prompt`, and `--skip-chat-parsing`.
- Feeds the prompt as `-p {PROMPT}` by default.
- Still supports `--interactive` at the analyzer level so you can pause between sections without typing `exit` into llama.cpp.

## Build

```bash
make
```

## Example

```bash
./QCAv9 \
  --input "/home/delta/iowa/2022 Iowa Code.pdf" \
  --reference "/home/delta/references/bill-of-rights.pdf" \
  --outdir "iowa-2022" \
  --runner-template 'llama-cli -m /home/delta/models/Qwen3-4B-Q4_K_M.gguf --jinja --reasoning on --reasoning-budget -1 -c {CTX_SIZE} -p {PROMPT}' \
  --ctx-size 2048 \
  --max-tokens 256
```

## Watch mode

```bash
./QCAv9 \
  --input "/home/delta/iowa/2022 Iowa Code.pdf" \
  --reference "/home/delta/references/bill-of-rights.pdf" \
  --outdir "iowa-2022" \
  --runner-template 'llama-cli -m /home/delta/models/Qwen3-4B-Q4_K_M.gguf --jinja --reasoning on --reasoning-budget -1 -c {CTX_SIZE} -p {PROMPT}' \
  --interactive \
  --show-prompts
```

## Output

- `report.md`
- `index.csv`
- `index.json`
- `work/section_XXXX.prompt.txt`
- `work/section_XXXX.raw.txt`
- `work/section_XXXX.json`
