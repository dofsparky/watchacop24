
#define _GNU_SOURCE
#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <sys/stat.h>
#include <unistd.h>

#define APP "qca"
#define DEFAULT_MAX_SECTION_CHARS 2200
#define DEFAULT_MAX_TOKENS 256
#define DEFAULT_CTX_SIZE 2048
#define DEFAULT_SUMMARY_CHARS 450

typedef struct { char *title; char *text; } Section;
typedef struct { Section *items; size_t len, cap; } SectionVec;

typedef struct { char *buf; size_t len, cap; } StrBuf;

static void sb_init(StrBuf *b) { b->buf = NULL; b->len = b->cap = 0; }
static void sb_free(StrBuf *b) { free(b->buf); b->buf = NULL; b->len = b->cap = 0; }
static void sb_reserve(StrBuf *b, size_t add) {
    size_t need = b->len + add + 1;
    if (need <= b->cap) return;
    size_t nc = b->cap ? b->cap : 1024;
    while (nc < need) nc *= 2;
    char *p = realloc(b->buf, nc);
    if (!p) { perror("realloc"); exit(1); }
    b->buf = p; b->cap = nc;
}
static void sb_append_n(StrBuf *b, const char *s, size_t n) {
    if (!s || !n) return;
    sb_reserve(b, n);
    memcpy(b->buf + b->len, s, n);
    b->len += n;
    b->buf[b->len] = '\0';
}
static void sb_append(StrBuf *b, const char *s) { if (s) sb_append_n(b, s, strlen(s)); }
static void sb_appendf(StrBuf *b, const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    va_list ap2;
    va_copy(ap2, ap);
    int n = vsnprintf(NULL, 0, fmt, ap);
    va_end(ap);
    if (n < 0) { va_end(ap2); return; }
    sb_reserve(b, (size_t)n);
    vsnprintf(b->buf + b->len, b->cap - b->len, fmt, ap2);
    va_end(ap2);
    b->len += (size_t)n;
}

static char *xstrdup(const char *s) {
    if (!s) s = "";
    size_t n = strlen(s);
    char *p = malloc(n + 1);
    if (!p) { perror("malloc"); exit(1); }
    memcpy(p, s, n + 1);
    return p;
}
static char *trim_ws(char *s) {
    if (!s) return s;
    char *start = s;
    while (*start && isspace((unsigned char)*start)) start++;
    char *end = start + strlen(start);
    while (end > start && isspace((unsigned char)end[-1])) end--;
    size_t n = (size_t)(end - start);
    if (start != s) memmove(s, start, n);
    s[n] = '\0';
    return s;
}
static char *dup_trim(const char *s) { char *p = xstrdup(s); return trim_ws(p); }
static char *to_upper_dup(const char *s) {
    size_t n = strlen(s);
    char *p = malloc(n + 1);
    if (!p) { perror("malloc"); exit(1); }
    for (size_t i = 0; i < n; i++) p[i] = (char)toupper((unsigned char)s[i]);
    p[n] = '\0';
    return p;
}
static bool contains_ci(const char *hay, const char *needle) {
    char *u1 = to_upper_dup(hay ? hay : "");
    char *u2 = to_upper_dup(needle ? needle : "");
    bool ok = strstr(u1, u2) != NULL;
    free(u1); free(u2);
    return ok;
}
static bool mostly_upper(const char *s) {
    int alpha = 0, upper = 0;
    for (; *s; s++) if (isalpha((unsigned char)*s)) { alpha++; if (isupper((unsigned char)*s)) upper++; }
    return alpha > 0 && upper * 2 >= alpha;
}
static bool looks_like_heading(const char *line) {
    char *t = dup_trim(line);
    if (!t || !*t) { free(t); return false; }
    size_t n = strlen(t);
    if (n > 140) { free(t); return false; }
    bool key = contains_ci(t, "CHAPTER") || contains_ci(t, "ARTICLE") || contains_ci(t, "SECTION")
               || contains_ci(t, "CODE OF IOWA") || contains_ci(t, "VOLUME ") || contains_ci(t, "TITLE ");
    bool num = isdigit((unsigned char)t[0]) || strncmp(t, "§", 2) == 0 || strncmp(t, "Sec.", 4) == 0 || strncmp(t, "SEC.", 4) == 0;
    bool upperish = mostly_upper(t) && n < 90 && !strchr(t, '.');
    free(t);
    return key || num || upperish;
}
static void vec_push(SectionVec *v, Section s) {
    if (v->len == v->cap) {
        size_t nc = v->cap ? v->cap * 2 : 64;
        Section *p = realloc(v->items, nc * sizeof(*p));
        if (!p) { perror("realloc"); exit(1); }
        v->items = p; v->cap = nc;
    }
    v->items[v->len++] = s;
}
static int ensure_dir(const char *path) {
    struct stat st;
    if (stat(path, &st) == 0) return S_ISDIR(st.st_mode) ? 0 : -1;
    return mkdir(path, 0755);
}
static int write_file(const char *path, const char *data) {
    FILE *f = fopen(path, "wb");
    if (!f) return -1;
    size_t n = data ? strlen(data) : 0;
    if (n && fwrite(data, 1, n, f) != n) { fclose(f); return -1; }
    fclose(f); return 0;
}
static char *read_file(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    if (fseek(f, 0, SEEK_END) != 0) { fclose(f); return NULL; }
    long sz = ftell(f);
    if (sz < 0) { fclose(f); return NULL; }
    rewind(f);
    char *buf = malloc((size_t)sz + 1);
    if (!buf) { fclose(f); return NULL; }
    size_t got = fread(buf, 1, (size_t)sz, f);
    fclose(f);
    buf[got] = '\0';
    return buf;
}
static char *shell_quote(const char *s) {
    StrBuf b; sb_init(&b);
    sb_append(&b, "'");
    for (const char *p = s; *p; p++) {
        if (*p == '\'') sb_append(&b, "'\\''");
        else sb_append_n(&b, p, 1);
    }
    sb_append(&b, "'");
    return b.buf;
}
static char *run_capture(const char *cmd) {
    StrBuf out; sb_init(&out);
    char *full = malloc(strlen(cmd) + 8);
    if (!full) { perror("malloc"); exit(1); }
    sprintf(full, "%s 2>&1", cmd);
    FILE *fp = popen(full, "r");
    free(full);
    if (!fp) return NULL;
    char buf[4096];
    while (fgets(buf, sizeof(buf), fp)) sb_append(&out, buf);
    pclose(fp);
    return out.buf;
}
static char *replace_all(const char *src, const char *needle, const char *repl) {
    if (!src) return xstrdup("");
    if (!needle || !*needle) return xstrdup(src);
    size_t src_len = strlen(src), nlen = strlen(needle), rlen = strlen(repl);
    size_t count = 0;
    const char *p = src;
    while ((p = strstr(p, needle))) { count++; p += nlen; }
    char *out = malloc(src_len + count * (rlen - nlen) + 1);
    if (!out) { perror("malloc"); exit(1); }
    char *d = out;
    p = src;
    const char *h;
    while ((h = strstr(p, needle))) {
        size_t n = (size_t)(h - p);
        memcpy(d, p, n); d += n;
        memcpy(d, repl, rlen); d += rlen;
        p = h + nlen;
    }
    strcpy(d, p);
    return out;
}
static char *extract_text_from_source(const char *path, const char *tmpdir) {
    const char *ext = strrchr(path, '.');
    if (ext && (strcasecmp(ext, ".txt") == 0 || strcasecmp(ext, ".md") == 0 || strcasecmp(ext, ".text") == 0))
        return read_file(path);

    if (ext && strcasecmp(ext, ".pdf") == 0) {
        char outpath[4096];
        snprintf(outpath, sizeof(outpath), "%s/extract_%ld.txt", tmpdir, (long)getpid());

        char *qin = shell_quote(path);
        char *qout = shell_quote(outpath);

        StrBuf cmd; sb_init(&cmd);
        sb_appendf(&cmd, "pdftotext -layout -nopgbrk %s %s >/dev/null 2>&1", qin, qout);
        int rc = system(cmd.buf);
        sb_free(&cmd);
        free(qin); free(qout);
        if (rc != 0) return NULL;

        char *txt = read_file(outpath);
        unlink(outpath);
        return txt;
    }
    return read_file(path);
}
static char *load_references(char **refs, size_t nrefs, const char *tmpdir) {
    if (nrefs == 0) return xstrdup("");
    StrBuf out; sb_init(&out);
    for (size_t i = 0; i < nrefs; i++) {
        char *txt = extract_text_from_source(refs[i], tmpdir);
        if (!txt) {
            fprintf(stderr, "%s: warning: unable to read reference %s\n", APP, refs[i]);
            continue;
        }
        sb_appendf(&out, "\n====================\nREFERENCE %zu\nSOURCE: %s\n--------------------\n", i + 1, refs[i]);
        sb_append(&out, txt);
        sb_append(&out, "\n");
        free(txt);
    }
    return out.buf ? out.buf : xstrdup("");
}
static void split_sections(const char *text, SectionVec *out, size_t max_chars) {
    char *copy = xstrdup(text ? text : "");
    char *save = NULL;
    char *line = strtok_r(copy, "\n", &save);

    char *title = xstrdup("(untitled section)");
    StrBuf buf; sb_init(&buf);
    size_t part = 1;

    while (line) {
        char *t = dup_trim(line);
        bool heading = looks_like_heading(t);

        if (heading && buf.len > 0) {
            vec_push(out, (Section){ .title = title, .text = buf.buf });
            title = xstrdup(t);
            sb_init(&buf);
            part = 1;
        } else if (heading && buf.len == 0 && strcmp(title, "(untitled section)") == 0) {
            free(title);
            title = xstrdup(t);
        } else {
            sb_append(&buf, line);
            sb_append(&buf, "\n");
            if (buf.len >= max_chars) {
                char titled[512];
                snprintf(titled, sizeof(titled), "%s%s", title, part == 1 ? "" : " (cont.)");
                vec_push(out, (Section){ .title = xstrdup(titled), .text = buf.buf });
                sb_init(&buf);
                part++;
            }
        }

        free(t);
        line = strtok_r(NULL, "\n", &save);
    }

    if (buf.len > 0) {
        char titled[512];
        snprintf(titled, sizeof(titled), "%s%s", title, part == 1 ? "" : " (cont.)");
        vec_push(out, (Section){ .title = xstrdup(titled), .text = buf.buf });
    } else {
        free(buf.buf);
    }

    free(title);
    free(copy);
    if (out->len == 0) vec_push(out, (Section){ .title = xstrdup("(untitled section)"), .text = xstrdup("") });
}
static char *build_prompt(const char *refs, const char *rolling, const Section *sec) {
    StrBuf b; sb_init(&b);
    sb_append(&b,
        "You are a local constitutional analyzer running offline on a low-RAM machine.\n"
        "Return concise JSON only with keys:\n"
        "section_title, possible_amendments, explanation, supporting_arguments, challenging_arguments, section_summary.\n"
        "Focus on the U.S. Bill of Rights only.\n"
        "Do not speculate beyond the text.\n"
        "If no likely Bill of Rights issue is present, return an empty possible_amendments array and explain why.\n\n");
    sb_append(&b, "BILL OF RIGHTS / REFERENCE MATERIAL:\n");
    sb_append(&b, refs && *refs ? refs : "(none loaded)\n");
    sb_append(&b, "\nROLLING CONTEXT SUMMARY:\n");
    sb_append(&b, rolling && *rolling ? rolling : "(none)\n");
    sb_append(&b, "\nCURRENT SECTION TITLE:\n");
    sb_append(&b, sec->title ? sec->title : "(untitled section)");
    sb_append(&b, "\n\nCURRENT SECTION TEXT:\n");
    sb_append(&b, sec->text ? sec->text : "");
    sb_append(&b, "\n");
    return b.buf;
}
static char *extract_summary(const char *out, size_t limit) {
    if (!out) return xstrdup("");
    const char *key = "\"section_summary\"";
    const char *p = strstr(out, key);
    if (p) {
        const char *colon = strchr(p, ':');
        if (colon) {
            const char *s = colon + 1;
            while (*s && isspace((unsigned char)*s)) s++;
            if (*s == '"') {
                s++;
                StrBuf b; sb_init(&b);
                for (; *s && b.len < limit; s++) {
                    if (*s == '\\' && s[1]) { s++; sb_append_n(&b, s, 1); }
                    else if (*s == '"') break;
                    else sb_append_n(&b, s, 1);
                }
                return b.buf ? b.buf : xstrdup("");
            }
        }
    }
    StrBuf b; sb_init(&b);
    const char *s = out;
    while (*s && isspace((unsigned char)*s)) s++;
    for (; *s && b.len < limit; s++) sb_append_n(&b, s, 1);
    return b.buf ? b.buf : xstrdup("");
}
static char *runner_cmd_from_template(const char *tmpl, const char *prompt_file, const char *prompt_text, size_t max_tokens, size_t ctx_size) {
    char max_buf[32], ctx_buf[32];
    snprintf(max_buf, sizeof(max_buf), "%zu", max_tokens);
    snprintf(ctx_buf, sizeof(ctx_buf), "%zu", ctx_size);

    char *qf = shell_quote(prompt_file);
    char *qp = shell_quote(prompt_text ? prompt_text : "");

    char *a = replace_all(tmpl, "{PROMPT_FILE}", qf);
    char *b = replace_all(a, "{PROMPT}", qp);
    char *c = replace_all(b, "{MAX_TOKENS}", max_buf);
    char *d = replace_all(c, "{CTX_SIZE}", ctx_buf);

    free(qf); free(qp); free(a); free(b); free(c);

    // Normalize any stale infinite-generation settings from older templates.
    char *e = replace_all(d, "-n -1", "-n ");
    free(d);
    d = e;
    char *f = replace_all(d, "--n-predict -1", "--n-predict ");
    free(d);
    d = f;

    StrBuf s; sb_init(&s);
    sb_append(&s, d);

    if (!strstr(d, " -n ") && !strstr(d, "--n-predict ")) {
        sb_appendf(&s, " -n %zu", max_tokens);
    }
    if (!strstr(d, "-st") && !strstr(d, "--single-turn")) {
        sb_append(&s, " --single-turn");
    }
    if (!strstr(d, "--simple-io")) {
        sb_append(&s, " --simple-io");
    }
    if (!strstr(d, "--no-display-prompt")) {
        sb_append(&s, " --no-display-prompt");
    }
    if (!strstr(d, "--skip-chat-parsing")) {
        sb_append(&s, " --skip-chat-parsing");
    }

    free(d);
    return s.buf;
}
static void csv_escape(FILE *f, const char *s) {
    fputc('"', f);
    for (; s && *s; s++) {
        if (*s == '"') fputc('"', f);
        fputc(*s, f);
    }
    fputc('"', f);
}
static void usage(void) {
    fprintf(stderr,
        "Usage: %s --input FILE --outdir DIR [options]\n\n"
        "Options:\n"
        "  --reference FILE        Add a reference document (repeatable; PDF or TXT)\n"
        "  --runner-template CMD   llama.cpp command template using {PROMPT} or {PROMPT_FILE}\n"
        "  --max-section-chars N   Chunk size before a forced split (default %d)\n"
        "  --max-tokens N          Tokens generated per section (default %d)\n"
        "  --ctx-size N            Context passed via {CTX_SIZE} (default %d)\n"
        "  --summary-chars N       Rolling summary limit (default %d)\n"
        "  --interactive           Pause between sections so users can watch the process\n"
        "  --show-prompts          Print prompts before each llama.cpp call\n"
        "  --pdf                   Try to write report.pdf with pandoc if available\n\n"
        "Example runner template:\n"
        "  llama-cli -m /home/delta/models/Qwen3-4B-Q4_K_M.gguf --jinja --reasoning on "
        "--reasoning-budget -1 -c {CTX_SIZE} --simple-io --no-display-prompt --skip-chat-parsing "
        "--single-turn --temp 0.6 --top-k 40 --top-p 0.95 --min-p 0.05 --repeat-penalty 1.05 "
        "-p {PROMPT}\n",
        APP, DEFAULT_MAX_SECTION_CHARS, DEFAULT_MAX_TOKENS, DEFAULT_CTX_SIZE, DEFAULT_SUMMARY_CHARS);
}

int main(int argc, char **argv) {
    const char *input = NULL;
    const char *outdir = NULL;
    const char *runner_template = NULL;
    bool want_pdf = false, interactive = false, show_prompts = false;
    size_t max_section_chars = DEFAULT_MAX_SECTION_CHARS;
    size_t max_tokens = DEFAULT_MAX_TOKENS;
    size_t ctx_size = DEFAULT_CTX_SIZE;
    size_t summary_chars = DEFAULT_SUMMARY_CHARS;

    char **refs = NULL;
    size_t nrefs = 0, refs_cap = 0;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--input") == 0 && i + 1 < argc) input = argv[++i];
        else if (strcmp(argv[i], "--outdir") == 0 && i + 1 < argc) outdir = argv[++i];
        else if (strcmp(argv[i], "--reference") == 0 && i + 1 < argc) {
            if (nrefs == refs_cap) {
                size_t nc = refs_cap ? refs_cap * 2 : 8;
                char **p = realloc(refs, nc * sizeof(*p));
                if (!p) { perror("realloc"); return 1; }
                refs = p; refs_cap = nc;
            }
            refs[nrefs++] = argv[++i];
        } else if (strcmp(argv[i], "--runner-template") == 0 && i + 1 < argc) runner_template = argv[++i];
        else if (strcmp(argv[i], "--max-section-chars") == 0 && i + 1 < argc) max_section_chars = (size_t)strtoul(argv[++i], NULL, 10);
        else if (strcmp(argv[i], "--max-tokens") == 0 && i + 1 < argc) max_tokens = (size_t)strtoul(argv[++i], NULL, 10);
        else if (strcmp(argv[i], "--ctx-size") == 0 && i + 1 < argc) ctx_size = (size_t)strtoul(argv[++i], NULL, 10);
        else if (strcmp(argv[i], "--summary-chars") == 0 && i + 1 < argc) summary_chars = (size_t)strtoul(argv[++i], NULL, 10);
        else if (strcmp(argv[i], "--pdf") == 0) want_pdf = true;
        else if (strcmp(argv[i], "--interactive") == 0) interactive = true;
        else if (strcmp(argv[i], "--show-prompts") == 0) show_prompts = true;
        else { usage(); return 1; }
    }

    if (!input || !outdir) { usage(); return 1; }
    if (ensure_dir(outdir) != 0) { fprintf(stderr, "%s: cannot create outdir %s\n", APP, outdir); return 1; }

    char workdir[4096];
    snprintf(workdir, sizeof(workdir), "%s/work", outdir);
    if (ensure_dir(workdir) != 0) { fprintf(stderr, "%s: cannot create workdir %s\n", APP, workdir); return 1; }

    char *input_text = extract_text_from_source(input, workdir);
    if (!input_text) { fprintf(stderr, "%s: pdftotext failed on %s\n", APP, input); return 1; }

    char *refs_text = load_references(refs, nrefs, workdir);
    SectionVec sections = {0};
    split_sections(input_text, &sections, max_section_chars);

    char report_md[4096], report_csv[4096], report_json[4096];
    snprintf(report_md, sizeof(report_md), "%s/report.md", outdir);
    snprintf(report_csv, sizeof(report_csv), "%s/index.csv", outdir);
    snprintf(report_json, sizeof(report_json), "%s/index.json", outdir);

    FILE *md = fopen(report_md, "wb");
    FILE *csv = fopen(report_csv, "wb");
    FILE *js = fopen(report_json, "wb");
    if (!md || !csv || !js) { perror("open output"); return 1; }

    fputs("# Constitutional Analyzer Report\n\n", md);
    fprintf(md, "- Input: `%s`\n", input);
    fprintf(md, "- References: %zu\n\n", nrefs);

    fputs("section_index,section_title,raw_output_file,summary\n", csv);
    fputs("{\n  \"sections\": [\n", js);

    char rolling[8192];
    rolling[0] = '\0';
    size_t json_count = 0;

    for (size_t i = 0; i < sections.len; i++) {
        Section *sec = &sections.items[i];
        char prompt_path[4096], raw_path[4096], json_path[4096];
        snprintf(prompt_path, sizeof(prompt_path), "%s/section_%04zu.prompt.txt", workdir, i + 1);
        snprintf(raw_path, sizeof(raw_path), "%s/section_%04zu.raw.txt", workdir, i + 1);
        snprintf(json_path, sizeof(json_path), "%s/section_%04zu.json", outdir, i + 1);

        char *prompt = build_prompt(refs_text, rolling, sec);
        if (write_file(prompt_path, prompt) != 0) {
            fprintf(stderr, "%s: could not write prompt file\n", APP);
            return 1;
        }

        if (!runner_template || !*runner_template) {
            fprintf(stderr, "%s: missing --runner-template\n", APP);
            return 1;
        }

        char *cmd = runner_cmd_from_template(runner_template, prompt_path, prompt, max_tokens, ctx_size);
        if (show_prompts) {
            printf("\n===== PROMPT %zu / %zu =====\n%s\n===========================\n", i + 1, sections.len, prompt);
        }
        printf("[%zu/%zu] %s\n", i + 1, sections.len, sec->title ? sec->title : "(untitled section)");
        fflush(stdout);

        char *raw = run_capture(cmd);
        if (!raw) {
            fprintf(stderr, "%s: failed to run llama.cpp command\n", APP);
            return 1;
        }

        write_file(raw_path, raw);
        write_file(json_path, raw);

        char *summary = extract_summary(raw, summary_chars);
        snprintf(rolling, sizeof(rolling), "%s", summary);
        free(summary);

        fprintf(md, "## %s\n\n", sec->title ? sec->title : "(untitled section)");
        fputs("### Raw output\n\n```text\n", md);
        fputs(raw, md);
        fputs("\n```\n\n", md);

        fprintf(csv, "%zu,", i + 1);
        csv_escape(csv, sec->title ? sec->title : "(untitled section)");
        fputc(',', csv);
        csv_escape(csv, raw_path);
        fputc(',', csv);
        csv_escape(csv, rolling);
        fputc('\n', csv);

        if (json_count++) fputs(",\n", js);
        fputs("    {\n", js);
        fprintf(js, "      \"index\": %zu,\n", i + 1);
        fputs("      \"section_title\": ", js); csv_escape(js, sec->title ? sec->title : "(untitled section)"); fputs(",\n", js);
        fputs("      \"raw_output_file\": ", js); csv_escape(js, raw_path); fputs(",\n", js);
        fputs("      \"summary\": ", js); csv_escape(js, rolling); fputc('\n', js);
        fputs("    }", js);

        free(prompt);
        free(cmd);
        free(raw);

        if (interactive) {
            printf("\n--- press ENTER for next section, or q then ENTER to stop ---\n");
            char line[16];
            if (!fgets(line, sizeof(line), stdin)) break;
            if (line[0] == 'q' || line[0] == 'Q') break;
        }
    }

    fputs("\n  ]\n}\n", js);
    fclose(md); fclose(csv); fclose(js);

    if (want_pdf) {
        char pdf_cmd[8192];
        snprintf(pdf_cmd, sizeof(pdf_cmd), "pandoc %s -o %s/report.pdf >/dev/null 2>&1", report_md, outdir);
        int rc = system(pdf_cmd);
        if (rc != 0) fprintf(stderr, "%s: warning: pandoc PDF generation failed\n", APP);
    }

    printf("Done. Reports written to %s.\n", outdir);
    printf("Use --interactive to pause between sections; llama.cpp runs single-turn and exits automatically.\n");

    for (size_t i = 0; i < sections.len; i++) {
        free(sections.items[i].title);
        free(sections.items[i].text);
    }
    free(sections.items);
    free(input_text);
    free(refs_text);
    free(refs);
    return 0;
}
