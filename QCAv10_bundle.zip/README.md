# QCAv10

QCAv10 adds resume/checkpoint support and a stronger Bill of Rights hierarchy prompt.

## Build

```bash
make
```

## Resume behavior

The analyzer writes checkpoint files in:

```text
<outdir>/.qca_state/
```

Files include:
- `next_section.txt`
- `rolling_summary.txt`
- `input_hash.txt`

If you stop the run with `Ctrl+C`, rerun the same command and it will continue from the next section.

## Start over

Use `--reset` to ignore old checkpoint data.

## Example

```bash
./QCAv10 \
  --input "/home/delta/iowa/2022-iowa-code.pdf" \
  --reference "/home/delta/references/bill-of-rights.pdf" \
  --outdir "iowa-2022" \
  --runner-template 'llama-cli -m /home/delta/models/Qwen3-4B-Q4_K_M.gguf --jinja --reasoning on --reasoning-budget -1 -c {CTX_SIZE} -p {PROMPT}' \
  --ctx-size 2048 \
  --max-tokens 256
```

## Interactive watch mode

```bash
./QCAv10 \
  --input "/home/delta/iowa/2022-iowa-code.pdf" \
  --reference "/home/delta/references/bill-of-rights.pdf" \
  --outdir "iowa-2022" \
  --runner-template 'llama-cli -m /home/delta/models/Qwen3-4B-Q4_K_M.gguf --jinja --reasoning on --reasoning-budget -1 -c {CTX_SIZE} -p {PROMPT}' \
  --interactive \
  --show-prompts
```
